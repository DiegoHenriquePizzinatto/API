<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nome_modelo = $_POST['nome_modelo'];
        $texto = $_POST['texto'];
        require_once "c0n3x40.php";
        echo $data = "null,'".$nome_modelo."', '".$texto."'";
        $insertedId = insertData($pdo,'tbl_modelos_email', $data);     

        echo "Modelo salvo com sucesso!";
    }
?>