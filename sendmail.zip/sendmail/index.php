<!DOCTYPE html>
<html>
<head>
<?php
  /*
  <--------------------------------------------
  |                                           |
  |      Dev.: pizzinattod                    |
  |      e-mail.:dpizzinatto@brascabos.com.br |
  |      dpt.:TI                              |
  |      Rev.:202501201511                    |
  -------------------------------------------->
*/
  if(!isset($_POST['nome']))
  {
    echo "<title>Gerador de Cartão de visitas virtual</title>";
  }
  else
  {
    echo "<title>Cartão Visita".$_POST['nome']."</title>";
  }
  ?>
  <meta http-equiv="Cache-control" content="no-cache">
  <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
  <script>

      function ir(acao, id)
      {
          var larg = window.innerWidth;
          var altu = window.innerHeight;
          if( acao == "cadastro" ){
                
              window.location.href="?va"; 

          }
          else if( acao == 'eliminar'){ 
              var resp = confirm("Desaja realmente efetuar a Exclusão");

              if( resp == true){
                document.cookie = "apagado=Cartão Excluido com Sucesso!!!";
                $.post("./3x3c.php?cartao="+id, function( data ) {
                   alert("Apagado com sucesso!");
                    window.location.reload(); 
                  
                });
             } 
        }
        else if( acao == 'editar'){

            window.location.href ="3d1t.php?id="+id;
        }
        else if (acao == "visualizar"){
            window.open('v13wc4rd.php?id=' + id, 'popup', 'width=600,height=400,scrollbars=yes,resizable=no');

        }
        else if (acao == "help"){
            window.open('./guia.pdf', 'popup', 'width='+ larg +',height='+ altu+',scrollbars=yes,resizable=no');

        }
        else if ( acao == 'baixaqr')
        {
          window.open('./downloadqrcode.php?id=' +id, '_blank');
        }
      }
  </script>
  <style>
  body
        {
            margin-top:0px;
            margin-left:0px;
            margin-right:0px;
            overflow: hidden;

        }
        /* Cartão gera pdf */
        #container
        {
          position:relative;
          margin-top:-390px;
          padding-left:-10px;
          margin-top:0px;
          width:100%;
          height:1679px;
          background-color:red;
          z-index:0;
        }
        #cartaobase
        {
          position:absolute;
          margin-top: -50px;
          margin-left:0px;
          background-repeat: no-repeat;
          background-size: 100%; background-position: center;
          /*width:1440px;
          height:2560px;*/
          min-width:100%;
          background-color:red;
          height:1730px;
          background-color:green;
          z-index:1;
        }
        #dados
        {
          position: absolute;
          padding-left: 200px;
          margin-top: 428px;
          text-align: justifY;
          font-family: "Calibri";
          font-size: 36pt;
          color: #000;
          z-index: 99999;

        }
        #site
        {
          position:absolute;
          padding-left:300px;
          margin-top:1313px;
          z-index:5;
        }
        #lks
        {
          position: absolute;
          padding-left: 172px;
          margin-top: 1318px;
          z-index: 4;
        }
        .logo{
          position: absolute;
          padding-left: 20px;
          margin-top: 270px;
          width: 1200px;
          height: 400;
          z-index: 3;
        }
        .btnacao 
        {
            width: 150;
            height: 150;
            padding: 10px;
            border: 0px;  
        }
        .fundo
        {
            position:absolute;
            width:100%;
            height: 100%;
        }    
        .site
        {
          width: 900;
          height: auto;
          margin-left: -191     px;
          margin-top:82px;
        
        }
        #vcardq
        { 

          position: absolute;
          margin-top:  798px;
          margin-left: 303px;
          z-index: 89;

          /*
          position: absolute;
          margin-top: 906px;
          margin-left: 390px;
          z-index: 89;*/
        }
        #nome{
          font-weight: bold;
          font-size: 42pt;
        }
        /* Fim Cartão gera pdf */
        /* Versao tela */
        #containertela
        {
          position:absolute;
          margin-top:-1000px;
          padding-left:0px;
          margin-top:0px;
          width:100%;
          height:1170px;
          z-index:6;
          background-color:#fff;
        }
        #cartaobasetela
        {
          position:absolute;
          margin-top: -50px;
          margin-left:0px;
          background-repeat: no-repeat;
          background-size: 100%; background-position: center;
          width:480px;
          height:768px;
          z-index:7;
        }
        #dadostela
        {
          position: absolute;
          padding-left: 70px;
          margin-top: 280px;
          text-align: justifY;
          font-family: "Calibri";
          font-size: 16pt;
          color: #000;
          z-index: 8;
        }
        #lkstela
        {
          position: absolute;
          padding-left: 40px;
          margin-top: 675px;
          z-index: 999999999;
        }
        .btnacaotela
        {
          width:60px;
          height:60px; 
          padding:10px;  
          border:0px;
        }
        .fundotela
        {
            position:absolute;
            width:100%;
            height: 100%;
        }
        .sitetela
        {
          width: 900;
          height: auto;
          margin-left: -130px;
          margin-top: -10px;
          display:none;
        }
        #vcardqtela
        {
          position: absolute;
          margin-top: 463px;
          margin-left: 101px;
          z-index: 89;
        }
        
        /* fim versao tela */
    @media print{
      .noprint{
          display:none;
          }
    }
    a
    {
      text-decoration: none;
    }
    #logo
    {
        width: 583px;
        height:200px;
    }
    
    /* Definindo o estilo para a tabela */
    table {
         border-collapse: collapse;
        }

        /* Estilizando as células da tabela */
       td {
            border: 1px solid #336bd1;
            padding: 8px;
            text-align: left;
        }
      .corpotabela{
        overflow-x: auto;
        height: 273px;
        width: 336px;
      }
      p{
        font-family: verdana;
        font-size:12px;
      }
      .bntadd{
        padding-left: 340px;
        padding-top: 43px;
        height: 7px;
      }
      .btimg{
         cursor:pointer;
      }
      #help{
        position: absolute;
        width: 30px;
        height: 30px;
        margin: 118px 445px;
        z-index: 9999999999;
        cursor:pointer;
      }
      #vcardform {
        position: absolute;
        padding-left: -13px;
        margin-top: -50px;
        width: 365px;
    }
    .btnvoltar {
    
    position: relative;
    width: 30px;
    height: 30px;
    margin-top: 65px;
    z-index: 9999999999999999999;
    cursor:pointer;

   }
   .title1,.title2, .title3, .title4, .title5{
    position: absolute;
    margin-top: -34px;
    text-align: center;
    background-color: blue-light;
    float: left;
    clear: both;
  }
  .title1{
     margin-left:27px;
  }
  .title2{
    margin-left:105px;
  }
  .title3{
    margin-left:156px;

  }
  .title4{
    margin-left:218px;

  }
  .title5{
    margin-left:281px;

  }
</style>
</head>
<body>
<?php
     
     //blc força vizualizar erros php no browser

      ini_set('display_errors', 1);
      ini_set('display_startup_errors', 1);
      error_reporting(E_ALL);
    
     //fim blc força vizualizar erros php no browser
     
     if(!isset($_GET['va'])){
      
      require "c0n3x40.php";
      $conteudo = selecionar($pdo,"null");
      
     $cartaotela = '<div id="containertela" class="noprint">
                        <div id="cartaobasetela">
                        <img src="./cmpts/matriz_topo_gerente.PNG" class="fundotela">  
                        <div id="help">
                          <img src="./img/help.png" width="30px" heigth="30px" onclick="ir('."'help'".')" title="Ajuda / Guia" />
                        </div>
                        <div id="dadostela">
                            <div class="bntadd">
                                <img src="./img/registro.png" width="30px" heigth="30px" class="btimg" alt="Cadastrar Cartão" onclick="ir('."'cadastro'".')" title="Cadastrar" />
                            </div>   
                          <!-- table>
                           <tr>
                              <td width="100px" align="center"><p>Nome</p></td>
                              <td width="40px" align="center"><p>Editar</p></td>
                              <td width="55px" align="center"><p>Visualizar</p></td>
                              <td width="55px" align="center"><p>QRCode</p></td>
                              <td width="55px" align="center"><p>Eliminar</p></td>
                          </tr>
                    </table -->
                              <div class="title1"><p>Nome</p></div>
                              <div class="title2"><p>Editar</p></div>
                              <div class="title3"><p>Visualizar</p></div>
                              <div class="title4"><p>QRCode</p></div>
                              <div class="title5"><p>Eliminar</p></div>
                    
                    ';
                   
      $cartaotela .= '<div class="corpotabela">
                    <table>';

        foreach ($conteudo as $dados)
        {
            if( $dados['id'] <> 1)
            {
               $cartaotela .="
                            <tr>
                                <td width='100px'><p>".$dados['nome']." ".$dados['nome_meio']." ".$dados['sobrenome']."</p></td>
                                <td width='40px'><center><img src='./img/editar.png' width='30px' heigth='30px' class='btimg' onclick='ir(".'"editar","'.$dados['id'].'"'.")' title='Editar' /></center></td>
                                <td width='55px'><center><img src='./img/binoculos.png' width='30px' heigth='30px' class='btimg' onclick='ir(".'"visualizar","'.$dados['id'].'"'.")' title='Visualizar'/><center></td>
                                <td width='55px'><center><img src='./img/qr.png' width='30px' heigth='30px' class='btimg' onclick='ir(".'"baixaqr","'.$dados['id'].'"'.")' title='Baixar Qrcode'/><center></td>
                                <td width='55px'><center><img src='./img/excluir.png' width='30px' heigth='30px' class='btimg' onclick='ir(".'"eliminar","'.$dados['id'].'"'.")' title='Eliminar'/></center></td>
                                
                            </tr>";
          }
        }
        $cartaotela .= "  </table>
                </div>";              
                                
      $cartaotela .='                    
                        </div>
                        </div>
                     </div>';  
                     
          echo $cartaotela;


     }
     else{
      
     if(!isset($_POST['nome'])){

        //form cadastro dados cartão visita
          echo '<div>
                  <div id="containertela" class="noprint">
                  <div id="cartaobasetela">
                     <img src="./cmpts/matriz_topo_gerente.PNG" class="fundotela">  
                  <div id="help">
                    <img src="./img/help.png" width="30px" heigth="30px" onclick="ir('."'help'".')" title="Ajuda / Guia" />
                  </div>
                  <div class="btnvoltar">
                                              <img src="./img/de-volta.png" onclick="window.history.back(-1)" class="btnvoltar" alt="voltar" title="Voltar" width="340px" height="30px" />
                                            </div>

                  <div id="dadostela">
                  <div id="vcardform">    
                        <form action="?gerar=s&tcf=ok&va=sim" method="post" >
                        <table>
                            <tr>
                              <td>Nome</td><td>
                              <input type="text" name="nome" required><br/></td>
                            </tr>
                            <tr>
                              <td>Telefone</td><td>
                              <input type="text" name="telefone" required></td>
                            </tr>
                            <tr>
                              <td>Celular</td>
                              <td><input type="text" name="celular" ></td>
                            </tr>
                            <tr>
                              <td>E-mail</td>
                              <td><input type="text" name="email" required></td>
                            </tr>
                            <!-- <tr>
                              <td>Linkedin</td>
                              <td><input type="text" name="linkedin" ></td>
                            </tr>
                            tr>
                              <td>Site <input type="text" name="site" required></td -->
                            </tr>  
                            <tr>
                              <td>Cargo</td>
                              <td><input type="text" name="cargo" required></td>
                            </tr>
                            <tr>
                              <td>Cargo em Inglês</td>
                              <td><input type="text" name="cargoen" ></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center"><center><input type="submit" value="Salvar"></center></td>
                            </tr>
                        </table>
                        </form>
                  </div>
             </div>
             </div>
             </div>';
                
      }
      else
      {
        

                //minera os _POSt
                  $nome = $_POST['nome']; 
                  $telefone =$_POST['telefone']; 
                  $telefonevcard ="+55(19)".$_POST['telefone']; 
                  if( $_POST['celular'] != "")
                  {
                    $celular = $_POST['celular']; 
                  }
                  else
                  {
                    $celular = ""; 
                  }
                  $email = $_POST['email']; 
                  $cargo = $_POST['cargo']; 
                  $cargoen = $_POST['cargoen'];
                  $nome2 = $nome;
                  $linkedin = 'https://br.linkedin.com/company/brascabos-componentes';
                  $arr_nome = explode(" ", $nome);
                  // monta do  meio
                  $nomedomeio = "";
                  $nomearq= $arr_nome[0];
                  $i = 1;
                  for($i  ; $i < count($arr_nome); $i++)
                  {
                          if($arr_nome[$i] != end($arr_nome))
                          {
                              $nomedomeio .= $arr_nome[$i];
                          }
                          
                          $nomearq .= $arr_nome[$i];
                          
                  }
                  
                  require_once "c0n3x40.php";
                  $data = "null,'".$arr_nome[0]."', '".$nomedomeio."', '".end($arr_nome)."', '".$telefone."', '".$celular."', '".$email."', '".$cargo."', '".$cargoen."'";
                  $insertedId = insertData($pdo,'d_vc', $data);  
                  //include "v13wc4rd.php?id=".$insertedId;
                  
                  echo "<script> ir(".'"visualizar","'.$insertedId.'"'.");
                                window.location.href='index.php'</script>";
                  unset($GLOBALS['nome']);
      }
  }
  
  
  ?>
