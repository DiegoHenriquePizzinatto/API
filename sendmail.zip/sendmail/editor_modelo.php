<?php
  /*
  <--------------------------------------------
  |                                           |
  |      Dev.: PIZZIDH                        |
  |      e-mail.:pizzidh@pizzinetwork.net     |
  |      Rev.:20260127                        |
  -------------------------------------------->
*/
?>
  <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>E-mail Modelo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        document.getElementById('formEditor').addEventListener('submit', function () {

            const botao = document.querySelector('.btn-salvar');
            const icone = botao.querySelector('i');

            // desabilita botão
            botao.disabled = true;

            // troca ícone para loading
            icone.classList.remove('fa-floppy-disk');
            icone.classList.add('fa-spinner', 'fa-spin-custom');

            // troca texto
            botao.lastChild.textContent = ' Salvando...';

        });
    </script>

    <script src="./ckeditor5/ckeditor.js"></script>
      <style>
        /* largura adaptativa */
        .editor-container {
            width: 100%;
            max-width: 100%;
        }

        /* altura do editor (≈100 linhas) */
        .ck-editor__editable {
            min-height: 200px;
        }
        .btn-salvar {
            background-color: #3bb3e0; /* azul celeste */
            color: #fff;
            border: none;
            padding: 12px 22px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.15s ease;
        }

        /* efeito hover */
        .btn-salvar:hover:not(:disabled) {
            background-color: #2aa1cf;
        }

        /* efeito pressionado */
        .btn-salvar:active:not(:disabled) {
            transform: translateY(2px);
            box-shadow: inset 0 3px 6px rgba(0,0,0,0.2);
        }

        /* botão desabilitado */
        .btn-salvar:disabled {
            background-color: #9ecfe3;
            cursor: not-allowed;
            opacity: 0.8;
        }

        /* animação do ícone */
        .fa-spin-custom {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }   
        .input-50 {
            width: 50ch;
            padding: 10px 12px;
            font-size: 15px;

            /* centro gelo */
            background-color: #f5fbff;

            /* bordas azuis */
            border: 2px solid #3bb3e0;

            /* cantos levemente arredondados */
            border-radius: 4px;

            /* sombra externa */
            box-shadow: 0 2px 6px rgba(59, 179, 224, 0.35);

            /* remove borda padrão */
            outline: none;

            transition: all 0.2s ease;
        }

        /* foco */
        .input-50:focus {
            background-color: #ffffff;
            box-shadow: 
                0 0 0 2px rgba(59, 179, 224, 0.35),
                0 4px 10px rgba(59, 179, 224, 0.45);
        }

    
    </style>
</head>
<body>

            <form method="post" id="formEditor" action="salvar_modelo.php">
                
                <div class="editor-container">
                    <input type="text" name="nome_modelo" length="100" value="" class="input-50" placeholder="Nome do modelo">
                    <textarea name="texto" id="editor"></textarea>
                    <br><br>
                    <button type="submit" class="btn-salvar">
                        <i class="fa-solid fa-floppy-disk"></i>
                        Salvar
                    </button>

                </div>
            </form>

            <script>
            let editorInstance;

            ClassicEditor
                .create(document.querySelector('#editor'))
                .then(editor => {
                    editorInstance = editor;
                })
                .catch(error => console.error(error));

            document.getElementById('formEditor').addEventListener('submit', function () {
                document.getElementById('editor').value = editorInstance.getData();
            });
            </script>

</body>
</html>
