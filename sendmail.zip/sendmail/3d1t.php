<!DOCTYPE html>
<html>
<head>

<?php
  /*
  <--------------------------------------------
  |                                           |
  |      Dev.: PIZZIDH                        |
  |      e-mail.:pizzidh@pizzinetwork.net     |
  |      Rev.:20260127                        |
  -------------------------------------------->
*/
  ?>
  <meta http-equiv="Cache-control" content="no-cache">
<?php

        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        require_once "c0n3x40.php";
        if(!isset($_POST['nome_modelo']))
        {
                $id = str_replace("#", "",  $_GET['id']);
                
                $conteudo = selecionar($pdo,$id);

                $nome = $conteudo[0]['nome_modelo'];
                $texto = $conteudo[0]['texto']; 
        }
        else{
            $id = str_replace("#", "", $_POST['id']);
            $nome_modelo = $_POST['nome_modelo'];
            $texto = $_POST['texto'];
            $sql = "  UPDATE `tbl_modelos_email` SET `nome_modelo` = '".$nome_modelo."', `texto` = '".$texto."' WHERE `id` = $id; ";
           $conteudo = UpdateData($pdo, $sql);
           if ( $conteudo == "ok")
           {

             require "v13wc4rd.php";
            
           }
             
      }

?>