<?php
        // Definindo os parâmetros de conexão
        $host = "manila"; 
        $username = 'dpizzinatto_dpizzinatto';
        $password = "S!st3m3m@D13go";
        $dbname = "cartaovisita";
        
        // cria conexão
        try {
            // Conexão PDO (se já estiver criada, ignore esta parte)
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
            // Chama a função insertData
          
        } catch (PDOException $e) {
            echo "Erro na conexão: " . $e->getMessage();
        }

        // Função para inserir dados na tabela
        function insertData($pdo, $table, $data) {
            
            $sql = "INSERT INTO tbl_modelos_email (id, nome_modelo, texto) VALUES ($data)";
            $statement = $pdo->query($sql);
           return $pesq = $pdo->lastInsertId();
                
        }
        
    function selecionar($pdo, $id)
    {
        
        
        if( $id == "null"){

            $sql = "SELECT *FROM d_vc";

        }
        else{
          
            $sql = "SELECT *FROM tbl_modelos_email WHERE id = $id";
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        
        $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

        
        if ($resultados) {
        
             return $resultados;

        } 
        else {
        
            echo "Nenhum registro encontrado.";
        }
    }
    function UpdateData($pdo, $sql) {
        try {
        
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
    
        
            if ($stmt->rowCount() > 0) {

                return "ok";

            } 
            else {
                return "nok tem algum erro nos dados";
            }
        } catch (PDOException $e) {
            // Se ocorrer um erro, exibe a mensagem de erro
            return "Error updating record: " . $e->getMessage();
        }
    }
    function DeleteData($pdo,$id){

        $sql = "DELETE FROM tbl_modelos_email WHERE id = '$id'"; 
        $stmt = $pdo->prepare($sql);

        // Executando a consulta
        $stmt->execute();
        return "apagado";

    }
    

?>
